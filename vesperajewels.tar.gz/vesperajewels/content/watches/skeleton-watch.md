---
name: Skeleton Watch
category: Skeleton
price: $7,600
description: Visible automatic movement through sapphire caseback. A window into fine Swiss watchmaking.
image: /assets/uploads/watch6.jpg
badge: ""
featured: false
published: true
---
